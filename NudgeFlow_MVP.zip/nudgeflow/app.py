from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from datetime import datetime, timedelta
import sqlite3, json, re, uuid

app=FastAPI(title='NudgeFlow')
templates=Jinja2Templates(directory='templates')
DB='nudgeflow.db'

SIGNALS={
 'buy later': 0.45, 'later':0.20, 'send link':0.35, 'payment link':0.35,
 'pay':0.25, 'checkout':0.25, 'order':0.15, 'buy':0.20, 'purchase':0.20,
 'keep it':0.25, 'reserve':0.25, 'how much':0.10, 'price':0.08, 'available':0.08
}
CASUAL=['nice','okay','thanks','cool','haha','just browsing','maybe','hello','hi']

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
 c=db(); c.executescript('''
 CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY, name TEXT, phone TEXT UNIQUE);
 CREATE TABLE IF NOT EXISTS chats(id INTEGER PRIMARY KEY, customer_id INTEGER, message TEXT, direction TEXT, created_at TEXT);
 CREATE TABLE IF NOT EXISTS leads(id INTEGER PRIMARY KEY, customer_id INTEGER, product TEXT, price REAL, intent_score REAL, status TEXT, followups INTEGER DEFAULT 0, next_followup TEXT, payment_link TEXT, recovered_at TEXT);
 CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, lead_id INTEGER, type TEXT, created_at TEXT, metadata TEXT);
 '''); c.commit(); c.close()
init()

def score(text):
 t=text.lower(); s=0
 for k,v in SIGNALS.items():
  if k in t: s+=v
 if any(x in t for x in CASUAL) and s<0.35: s*=0.35
 return min(0.99, round(s,2))

def recent_reply(lead_id, after):
 c=db(); r=c.execute("SELECT COUNT(*) n FROM chats ch JOIN leads l ON l.customer_id=ch.customer_id WHERE l.id=? AND ch.direction='in' AND ch.created_at>?",(lead_id,after)).fetchone(); c.close(); return r['n']>0

def event(lead_id, typ, meta={}):
 c=db(); c.execute('INSERT INTO events(lead_id,type,created_at,metadata) VALUES(?,?,?,?)',(lead_id,typ,datetime.utcnow().isoformat(),json.dumps(meta))); c.commit(); c.close()

def process_incoming(name,phone,message,product='Product',price=999):
 c=db(); c.execute('INSERT OR IGNORE INTO customers(name,phone) VALUES(?,?)',(name,phone)); cid=c.execute('SELECT id FROM customers WHERE phone=?',(phone,)).fetchone()['id']
 c.execute('INSERT INTO chats(customer_id,message,direction,created_at) VALUES(?,?,?,?)',(cid,message,'in',datetime.utcnow().isoformat())); s=score(message)
 if s>=0.55:
  link='https://example.com/pay/'+uuid.uuid4().hex[:10]
  nf=(datetime.utcnow()+timedelta(minutes=30)).isoformat()
  c.execute('INSERT INTO leads(customer_id,product,price,intent_score,status,followups,next_followup,payment_link) VALUES(?,?,?,?,?,?,?,?)',(cid,product,price,s,'scheduled',0,nf,link)); lid=c.lastrowid; c.commit(); event(lid,'intent_detected',{'score':s});
 else: c.commit(); lid=None
 c.close(); return s,lid

@app.get('/',response_class=HTMLResponse)
def home(request:Request):
 c=db(); leads=c.execute('''SELECT l.*,c.name,c.phone FROM leads l JOIN customers c ON c.id=l.customer_id ORDER BY l.id DESC''').fetchall();
 total=c.execute("SELECT COUNT(*) n FROM leads").fetchone()['n']; recovered=c.execute("SELECT COUNT(*) n FROM leads WHERE status='recovered'").fetchone()['n']; sent=c.execute("SELECT COUNT(*) n FROM events WHERE type='followup_sent'").fetchone()['n']; clicks=c.execute("SELECT COUNT(*) n FROM events WHERE type='payment_clicked'").fetchone()['n']; c.close()
 return templates.TemplateResponse('dashboard.html',{'request':request,'leads':leads,'total':total,'recovered':recovered,'sent':sent,'clicks':clicks,'rate':round(recovered/total*100,1) if total else 0})

@app.post('/simulate')
def simulate(name: str=Form(...), phone: str=Form(...), message: str=Form(...), product: str=Form('Black Hoodie'), price: float=Form(1499)):
 process_incoming(name,phone,message,product,price); return RedirectResponse('/',303)

@app.post('/run-scheduler')
def scheduler():
 c=db(); now=datetime.utcnow().isoformat(); rows=c.execute("SELECT l.*,c.name FROM leads l JOIN customers c ON c.id=l.customer_id WHERE l.status='scheduled' AND l.next_followup<=?",(now,)).fetchall(); count=0
 for l in rows:
  if l.followups>=2: c.execute("UPDATE leads SET status='capped' WHERE id=?",(l.id,)); continue
  if recent_reply(l.id,l.next_followup or now): c.execute("UPDATE leads SET status='stopped_reply' WHERE id=?",(l.id,)); event(l.id,'stopped_reply'); continue
  msg=f"Hi {l['name']}! Still interested in the {l['product']}? You can complete your order here: {l['payment_link']}"
  c.execute("UPDATE leads SET followups=followups+1,status='sent' WHERE id=?",(l.id,)); event(l.id,'followup_sent',{'message':msg}); count+=1
 c.commit(); c.close(); return {'sent':count}

@app.post('/click/{lead_id}')
def click(lead_id:int): event(lead_id,'payment_clicked'); return RedirectResponse('/',303)

@app.post('/recover/{lead_id}')
def recover(lead_id:int):
 c=db(); c.execute("UPDATE leads SET status='recovered',recovered_at=? WHERE id=?",(datetime.utcnow().isoformat(),lead_id)); c.commit(); c.close(); event(lead_id,'purchase_recovered'); return RedirectResponse('/',303)
