# NudgeFlow MVP

A hackathon-ready prototype for WhatsApp abandonment recovery.

## What it demonstrates
- Intent scoring from WhatsApp-style messages
- High-intent threshold before automation
- 30-minute scheduled follow-up
- Maximum 2 follow-ups
- Stop on reply / purchase / cap
- Personalized payment-link nudge
- Recovery dashboard

## Run
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```
Open http://127.0.0.1:8000

## Demo
1. Enter: `I'll buy later, send me the payment link`.
2. The lead should score high and become `scheduled`.
3. For a live 30-min demo, temporarily change `timedelta(minutes=30)` in `app.py` to `timedelta(seconds=10)`.
4. Click **Run Due Follow-ups**.
5. Simulate a payment click or mark recovered.

## Production integrations
Replace the simulator with the official WhatsApp Business Cloud API webhook and a real payment provider. Add authentication, encrypted secrets, message-template approval, rate limits, consent/opt-out handling, audit logs, queue workers, and tenant isolation before production use.
